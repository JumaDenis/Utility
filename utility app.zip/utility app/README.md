# UTILITY APP

Brief: This is a miniscule JavaScript project aimed at improving my skills on the Document Object Model and to hone some CSS skills.

## JavaScript functionality

- The carousel: Included in the intro part of the project
- Date & time: Included to show the time of the day
- To do list app: Beginner level app for DOM interaction
- Expense tracker: For extensive knowledge on arrays and objects

This is a very beginner friendly project
